package Java_Advanced.demo.controllers;

import Java_Advanced.demo.model.dto.BookDTO;
import Java_Advanced.demo.service.impl.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;

    @PostMapping
    public BookDTO createBook(@RequestBody BookDTO bookDTO) {

        return bookService.createBook(bookDTO);
    }
}
