package Java_Advanced.demo.controllers;

import Java_Advanced.demo.model.dto.BookShopDTO;
import Java_Advanced.demo.service.impl.BookShopService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bookshops")
@RequiredArgsConstructor
public class BookShopController {

    private final BookShopService bookShopService;

    @PostMapping
    public BookShopDTO createBookShop(@RequestBody BookShopDTO bookShopDTO) {
        return bookShopService.createBookShop(bookShopDTO);
    }
}
