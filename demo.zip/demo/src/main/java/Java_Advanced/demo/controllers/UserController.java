package Java_Advanced.demo.controllers;

import Java_Advanced.demo.model.dto.UserDTO;
import Java_Advanced.demo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping
    public UserDTO createUser(@RequestBody UserDTO userDTO) {
//        Контроллер вернёт ЮзерДТО когда мы будем сохранять пользователя,
//        реквест боди для указания Юзер ДТО передаётся в боди
        return userService.createUser(userDTO);
//        Передаём Юзер Дто как метод
    }


}
