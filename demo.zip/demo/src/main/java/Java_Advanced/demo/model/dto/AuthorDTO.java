package Java_Advanced.demo.model.dto;

import Java_Advanced.demo.model.enums.Gender;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthorDTO {

    String firstName;
    String lastName;
    Gender gender;
    String dateOfBirth;

}
