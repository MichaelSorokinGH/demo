package Java_Advanced.demo.model.dto;

import Java_Advanced.demo.model.entity.Author;
import Java_Advanced.demo.model.enums.BookCondition;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.util.List;

@Getter
@Setter
public class BookDTO {
    @Enumerated(EnumType.STRING)
//    С этой аннотацией в БД будет прописываться не число, а строка
//    (Тут вопрос нужно ли тут использовать данную аннотацию?
    BookCondition bookCondition;

    String bookTitle;
//    Енум Отдельный тип данных, отдельное поле, которое используется у Книги
    String publicationDate;
//    Лучше использовать стринг
    Integer authorsCount;

    List<AuthorDTO> authors;


}
