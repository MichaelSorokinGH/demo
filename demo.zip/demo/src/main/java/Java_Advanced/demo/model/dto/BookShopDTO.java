package Java_Advanced.demo.model.dto;

import Java_Advanced.demo.model.enums.BookCondition;
import lombok.Getter;
import lombok.Setter;


import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.util.List;

@Getter
@Setter
public class BookShopDTO {

    String revisionNumber;


//    Енум Отдельный тип данных, отдельное поле, которое используется у Книги
    String dateOfSale;

    List<BookDTO> books;

}
