package Java_Advanced.demo.model.dto;

import Java_Advanced.demo.model.enums.Gender;
import lombok.Getter;
import lombok.Setter;


import java.util.List;
@Getter
@Setter
public class UserDTO {

    Integer age;
    String firstName;
    String lastName;
    Gender gender;
//    Енум Отдельный тип данных, отдельное поле, которое используется у Юзера
    List<BookDTO> books;
//    Коллекция для связи между пользователем и книгой

//    ВСЕ ЭТИ ТРАНСФЕРНЫЕ КЛАССЫ ИДУТ ОТ КЛИЕНТА!
}
