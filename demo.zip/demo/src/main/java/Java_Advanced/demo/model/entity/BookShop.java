package Java_Advanced.demo.model.entity;

import Java_Advanced.demo.model.enums.BookCondition;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Entity
//Аннотация говорит о том что этот класс является сущностью для бд
@Table(name = "book_shops")
//название таблицы, принято указывать во множественном числе
@FieldDefaults(level = AccessLevel.PRIVATE)
//Аннотация задающая для всех полей модификатор Private
public class BookShop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
////Задаёт автоинкремент, счётчик увеличивается
//(каждый раз когда создаётся пользователь - счётчик будет крутиться, создавать новый ID
    Long id;

    @Column(name = "revision_number")
    Integer revisionNumber;

    @Column(name = "date_of_sale")
    LocalDate dateOfSale;


    @OneToMany(cascade = CascadeType.ALL)
//    Магазин имеет много книг
    List<Book> books;
//    Коллекция для связи между магазином и книгами

}
