package Java_Advanced.demo.model.enums;

public enum BookCondition {

    NEW,
    GOOD,
    USED,
    BAD


}
