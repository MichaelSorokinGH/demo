package Java_Advanced.demo.model.repository;

import Java_Advanced.demo.model.entity.BookShop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookShopRepository extends JpaRepository<BookShop, Long> {
}
