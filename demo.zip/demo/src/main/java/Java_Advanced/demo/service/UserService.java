package Java_Advanced.demo.service;

import Java_Advanced.demo.model.dto.UserDTO;

public interface UserService {

    UserDTO createUser(UserDTO userDTO);
//    Метод который будет принимать ЮзерДто в качестве параметра
}
