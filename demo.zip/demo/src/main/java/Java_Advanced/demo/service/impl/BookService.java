package Java_Advanced.demo.service.impl;

import Java_Advanced.demo.model.dto.BookDTO;

public interface BookService {

    BookDTO createBook(BookDTO bookDTO);
    //    Метод который будет принимать БукДто в качестве параметра
}


