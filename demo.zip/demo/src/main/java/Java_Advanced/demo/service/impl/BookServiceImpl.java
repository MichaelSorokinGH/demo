package Java_Advanced.demo.service.impl;

import Java_Advanced.demo.model.dto.AuthorDTO;
import Java_Advanced.demo.model.dto.BookDTO;
import Java_Advanced.demo.model.entity.Author;
import Java_Advanced.demo.model.entity.Book;
import Java_Advanced.demo.model.repository.BookRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;

    private final ObjectMapper mapper;

    @Override
    public BookDTO createBook(BookDTO bookDTO) {

        Book book = mapper.convertValue(bookDTO, Book.class);

        List<Author> authors = bookDTO.getAuthors().stream()
                .map(a -> {
                    Author author = new Author();
                    author.setFirstName(a.getFirstName());
                    author.setLastName(a.getLastName());
                    author.setGender(a.getGender());
                    author.setDateOfBirth(a.getDateOfBirth());
                    return author;
                })
                .collect(Collectors.toList());

        book.setAuthors(authors);

        Book save = bookRepository.save(book);

        BookDTO result = mapper.convertValue(book, BookDTO.class);
        List<AuthorDTO> authorsDTO = book.getAuthors().stream()
                .map(a -> {

                    AuthorDTO authorDTO = new AuthorDTO();
                    authorDTO.setFirstName(a.getFirstName());
                    authorDTO.setLastName(a.getLastName());
                    authorDTO.setGender(a.getGender());
                    authorDTO.setDateOfBirth(a.getDateOfBirth());
                    return authorDTO;
                })
                .collect(Collectors.toList());

        result.setAuthors(authorsDTO);

        return bookDTO;
    }
}
