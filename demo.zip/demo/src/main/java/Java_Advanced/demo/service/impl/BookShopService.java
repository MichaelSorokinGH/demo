package Java_Advanced.demo.service.impl;

import Java_Advanced.demo.model.dto.BookShopDTO;

public interface BookShopService {

    BookShopDTO createBookShop(BookShopDTO bookShopDTO);

}
