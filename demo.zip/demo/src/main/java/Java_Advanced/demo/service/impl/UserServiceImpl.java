package Java_Advanced.demo.service.impl;

import Java_Advanced.demo.model.dto.BookDTO;
import Java_Advanced.demo.model.dto.BookShopDTO;
import Java_Advanced.demo.model.dto.UserDTO;
import Java_Advanced.demo.model.entity.Book;
import Java_Advanced.demo.model.entity.User;
import Java_Advanced.demo.model.repository.UserRepository;
import Java_Advanced.demo.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
//Ломбок
@Service
//Создаёт Bean данного класса, скажет спрингу что данный класс является бином. поднятие контекста проинициализируется.
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ObjectMapper mapper;
//    Для того что бы сократить часть кода, полей
    @Override
    public UserDTO createUser(UserDTO userDTO) {

//        User user = new User();
//        user.setAge(userDTO.getAge());
//        user.setFirstName(userDTO.getFirstName());
//        user.setLastName(userDTO.getLastName());
//        user.setGender(userDTO.getGender());

        User user = mapper.convertValue(userDTO, User.class);
//        Преобразование юзераДТО к юзеру, сконвертированный с трансферного объекта сущность юзер
//        Маппер отрабатывает одинаковые поля и тип данных, если тип данных разный пишем вручную ниже

        user.setCreatedAt(LocalDateTime.now());
//        Прописывается что юзер создаётся сейчас

        List<Book> books = userDTO.getBooks().stream()
                .map(b -> {
                    Book book = new Book();
                    book.setBookTitle(b.getBookTitle());
                    book.setBookCondition(b.getBookCondition());
                    book.setAuthorsCount(b.getAuthorsCount());
                    try {
                        book.setPublicationDate(LocalDate.parse(b.getPublicationDate()));
                    } catch (Exception e) {
                       log.error(e.getMessage());
                       throw new RuntimeException(e);
                    }
                    return book;
                })
                .collect(Collectors.toList());
//        Хотим создать объект нашего пользователя,
//        преобразовали через маппер наш трансферный объект(ЮзерДТО) к нашей сущности юзер,
//        далее берем все книги, которые есть у нашего трансферного объекта, через стрим мы
//        раскладываем и собираем список книг и в конце мы устанавливаем юзеру все те книги которые мы
//        получили из трансферного объекта

        user.setBooks(books);

        User save = userRepository.save(user);
//      Сохраняем. сэйв принимает энтити(сущность) в данном случае юзера
//        стандартный метод, который даёт возможность сохранения в базу

        UserDTO result = mapper.convertValue(user, UserDTO.class);
        List<BookDTO> booksDTO = user.getBooks().stream()
                .map(b -> {

                    BookDTO bookDTO = new BookDTO();
                    bookDTO.setBookTitle(b.getBookTitle());
                    bookDTO.setBookCondition(b.getBookCondition());
                    bookDTO.setAuthorsCount(b.getAuthorsCount());
                    bookDTO.setPublicationDate(String.valueOf(b.getPublicationDate()));
                    return bookDTO;
                })
                .collect(Collectors.toList());

        result.setBooks((booksDTO));


        return userDTO;
//        при return null не отображается в боди постмана ответ

//        Создаём юзера, сеттером добавляем ему значения, геттером из ДТО забираем
    }
}
